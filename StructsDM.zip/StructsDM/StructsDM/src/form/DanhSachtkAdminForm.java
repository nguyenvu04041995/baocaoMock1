package form;

import java.util.ArrayList;

import org.apache.struts.action.ActionForm;

import model.bean.QuanlitaikhoanAdmin;


public class DanhSachtkAdminForm extends ActionForm {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String tenDangNhap;
	private int page;
	private int totalPage;
	private String key;
	private ArrayList<QuanlitaikhoanAdmin> listQuanlitaikhoanAdmin;

	
	public DanhSachtkAdminForm() {
		super();
	}

	

	public DanhSachtkAdminForm(String tenDangNhap, int page, int totalPage, String key,
			ArrayList<QuanlitaikhoanAdmin> listQuanlitaikhoanAdmin) {
		super();
		this.tenDangNhap = tenDangNhap;
		this.page = page;
		this.totalPage = totalPage;
		this.key = key;
		this.listQuanlitaikhoanAdmin = listQuanlitaikhoanAdmin;
	}



	public String getKey() {
		return key;
	}

	public void setKey(String key) {
		this.key = key;
	}

	public String getTenDangNhap() {
		return tenDangNhap;
	}

	public void setTenDangNhap(String tenDangNhap) {
		this.tenDangNhap = tenDangNhap;
	}

	public int getPage() {
		return page;
	}

	public void setPage(int page) {
		this.page = page;
	}

	public int getTotalPage() {
		return totalPage;
	}

	public void setTotalPage(int totalPage) {
		this.totalPage = totalPage;
	}

	public ArrayList<QuanlitaikhoanAdmin> getListQuanlitaikhoanAdmin() {
		return listQuanlitaikhoanAdmin;
	}

	public void setListQuanlitaikhoanAdmin(ArrayList<QuanlitaikhoanAdmin> listQuanlitaikhoanAdmin) {
		this.listQuanlitaikhoanAdmin = listQuanlitaikhoanAdmin;
	}
	
}
