package form;

import java.util.ArrayList;

import org.apache.struts.action.ActionForm;

import model.bean.TaiKhoanNhaTuyenDung;
import model.bean.TrangThai;
/**
 * 
 * @author HCD-Fresher185
 *
 */

public class DanhSachtkNhaTuyenDungForm extends ActionForm{
	private String maID;
	private int page;
	private int totalPage;
	private String key;
	private int trangThai;
	private ArrayList<TrangThai> listTrangThai;
	private ArrayList<TaiKhoanNhaTuyenDung> listTaiKhoanNhaTuyenDung;
	
	/**
	 * 
	 */

	public DanhSachtkNhaTuyenDungForm() {
		super();
	}
	public DanhSachtkNhaTuyenDungForm(String maID, int page, int totalPage, String key, int trangThai,
			ArrayList<TrangThai> listTrangThai, ArrayList<TaiKhoanNhaTuyenDung> listTaiKhoanNhaTuyenDung) {
		super();
		this.maID = maID;
		this.page = page;
		this.totalPage = totalPage;
		this.key = key;
		this.trangThai = trangThai;
		this.listTrangThai = listTrangThai;
		this.listTaiKhoanNhaTuyenDung = listTaiKhoanNhaTuyenDung;
	}
	public String getMaID() {
		return maID;
	}
	public void setMaID(String maID) {
		this.maID = maID;
	}
	public int getPage() {
		return page;
	}
	public void setPage(int page) {
		this.page = page;
	}
	public int getTotalPage() {
		return totalPage;
	}
	public void setTotalPage(int totalPage) {
		this.totalPage = totalPage;
	}
	public String getKey() {
		return key;
	}
	public void setKey(String key) {
		this.key = key;
	}
	public int getTrangThai() {
		return trangThai;
	}
	public void setTrangThai(int trangThai) {
		this.trangThai = trangThai;
	}
	public ArrayList<TrangThai> getListTrangThai() {
		return listTrangThai;
	}
	public void setListTrangThai(ArrayList<TrangThai> listTrangThai) {
		this.listTrangThai = listTrangThai;
	}
	public ArrayList<TaiKhoanNhaTuyenDung> getListTaiKhoanNhaTuyenDung() {
		return listTaiKhoanNhaTuyenDung;
	}
	public void setListTaiKhoanNhaTuyenDung(ArrayList<TaiKhoanNhaTuyenDung> listTaiKhoanNhaTuyenDung) {
		this.listTaiKhoanNhaTuyenDung = listTaiKhoanNhaTuyenDung;
	}
	
	
	
	
}
