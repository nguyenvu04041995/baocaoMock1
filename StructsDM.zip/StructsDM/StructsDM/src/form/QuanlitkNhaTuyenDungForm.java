package form;

import java.io.UnsupportedEncodingException;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts.action.ActionMapping;


import model.bean.TaiKhoanNhaTuyenDung;

public class QuanlitkNhaTuyenDungForm {
	/**
	 * 
	 * 
	 * 
	 */
	
	private int maID;
	private String tenNhaTuyenDung;
	private String email;
	private int trangThai;
	private String tentrangThai;
	private String action;
	private String submit;
	
	/****
	 * 
	 * 
	 * 
	 */
	
	
	
	
	private TaiKhoanNhaTuyenDung taiKhoanNhaTuyenDung;
	public QuanlitkNhaTuyenDungForm() {
		super();
	}
	public QuanlitkNhaTuyenDungForm(int maID, String tenNhaTuyenDung, String email, int trangThai, String tentrangThai,
			String action, String submit, TaiKhoanNhaTuyenDung taiKhoanNhaTuyenDung) {
		super();
		this.maID = maID;
		this.tenNhaTuyenDung = tenNhaTuyenDung;
		this.email = email;
		this.trangThai = trangThai;
		this.tentrangThai = tentrangThai;
		this.action = action;
		this.submit = submit;
		this.taiKhoanNhaTuyenDung = taiKhoanNhaTuyenDung;
	}
	public int getMaID() {
		return maID;
	}
	public void setMaID(int maID) {
		this.maID = maID;
	}
	public String getTenNhaTuyenDung() {
		return tenNhaTuyenDung;
	}
	public void setTenNhaTuyenDung(String tenNhaTuyenDung) {
		this.tenNhaTuyenDung = tenNhaTuyenDung;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public int getTrangThai() {
		return trangThai;
	}
	public void setTrangThai(int trangThai) {
		this.trangThai = trangThai;
	}
	public String getTenrtrangThai() {
		return tentrangThai;
	}
	public void setTenrtrangThai(String tenrtrangThai) {
		this.tentrangThai = tenrtrangThai;
	}
	public String getAction() {
		return action;
	}
	public void setAction(String action) {
		this.action = action;
	}
	public String getSubmit() {
		return submit;
	}
	public void setSubmit(String submit) {
		this.submit = submit;
	}
	public TaiKhoanNhaTuyenDung getTaiKhoanNhaTuyenDung() {
		return taiKhoanNhaTuyenDung;
	}
	public void setTaiKhoanNhaTuyenDung(TaiKhoanNhaTuyenDung taiKhoanNhaTuyenDung) {
		this.taiKhoanNhaTuyenDung = taiKhoanNhaTuyenDung;
	}
	
	public void reset(ActionMapping mapping, HttpServletRequest request) {
		try {
			request.setCharacterEncoding("UTF-8");
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
	}
	
}
