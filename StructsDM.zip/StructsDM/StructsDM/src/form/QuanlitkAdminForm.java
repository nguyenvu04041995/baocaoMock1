package form;

import java.io.UnsupportedEncodingException;


import javax.servlet.http.HttpServletRequest;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;

import model.bean.QuanlitaikhoanAdmin;


public class QuanlitkAdminForm extends ActionForm{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String tenDangNhap;
	private String matKhau;
	
	private String action;
	private String submit;
	private QuanlitaikhoanAdmin quanlitaikhoanAdmin;
	
	
	
	public QuanlitkAdminForm() {
		super();
	}
	public QuanlitkAdminForm(String tenDangNhap, String matKhau, String action, String submit,
			QuanlitaikhoanAdmin quanlitaikhoanAdmin) {
		super();
		this.tenDangNhap = tenDangNhap;
		this.matKhau = matKhau;
		this.action = action;
		this.submit = submit;
		this.quanlitaikhoanAdmin = quanlitaikhoanAdmin;
	}
	public String getTenDangNhap() {
		return tenDangNhap;
	}
	public void setTenDangNhap(String tenDangNhap) {
		this.tenDangNhap = tenDangNhap;
	}
	public String getMatKhau() {
		return matKhau;
	}
	public void setMatKhau(String matKhau) {
		this.matKhau = matKhau;
	}
	public String getAction() {
		return action;
	}
	public void setAction(String action) {
		this.action = action;
	}
	public String getSubmit() {
		return submit;
	}
	public void setSubmit(String submit) {
		this.submit = submit;
	}
	public QuanlitaikhoanAdmin getQuanlitaikhoanAdmin() {
		return quanlitaikhoanAdmin;
	}
	public void setQuanlitaikhoanAdmin(QuanlitaikhoanAdmin quanlitaikhoanAdmin) {
		this.quanlitaikhoanAdmin = quanlitaikhoanAdmin;
	}
	@Override
	public void reset(ActionMapping mapping, HttpServletRequest request) {
		try {
			request.setCharacterEncoding("UTF-8");
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
	}
	
	
}
