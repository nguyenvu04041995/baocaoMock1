package model.DAO;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class AdminDAO {

	public boolean checkLoginAdmin(String tenDangNhap, String matKhau) {
		
		ConnectData.connection = ConnectData.getconnect();
		String sql = "select * from tb_NguoiQuanTri where TenDangNhap='"
				+ tenDangNhap + "' and MatKhau='" + matKhau + "'";
		ResultSet rs=null;
		Statement stmt=null;
		try {
			 stmt=ConnectData.connection.createStatement();
			 rs=stmt.executeQuery(sql);
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}try {
			if(rs.next()){
				return true;
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return false;
	}

}
