package model.DAO;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;


import model.bean.TaiKhoanNhaTuyenDung;

public class TaiKhoanNhaTuyenDungDAO {

	public ArrayList<TaiKhoanNhaTuyenDung> getlistquanliTaiKhoanNhaTuyenDung() {
		ConnectData.connection = ConnectData.getconnect();
		String sql ="SELECT MaID,TenNhaTuyenDung,Email,t.TenTrangThai"
				+ " from tb_NhaTuyenDung n inner join tb_TrangThai AS t ON t.TrangThai=n.TrangThai ";
		ResultSet rs=null;
		try {
			Statement stmt=ConnectData.connection.createStatement();
			rs=stmt.executeQuery(sql);
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		ArrayList<TaiKhoanNhaTuyenDung>list =new ArrayList<>();
		TaiKhoanNhaTuyenDung taiKhoanNhaTuyenDung;
		try {
			while(rs.next()){
				taiKhoanNhaTuyenDung =new TaiKhoanNhaTuyenDung();
				taiKhoanNhaTuyenDung.setMaID(rs.getInt("maID"));
				taiKhoanNhaTuyenDung.setTenNhaTuyenDung(rs.getString("tenNhaTuyenDung"));
				taiKhoanNhaTuyenDung.setEmail(rs.getString("email"));
				taiKhoanNhaTuyenDung.setTentrangThai(rs.getString("tentrangThai"));
				list.add(taiKhoanNhaTuyenDung);
			}
		} catch (SQLException e) {
	
			e.printStackTrace();
		}
		return list;
	}

	public TaiKhoanNhaTuyenDung getThongTinTaiKhoanNhaTuyenDung(int maID) {
		ConnectData.connection = ConnectData.getconnect();
		String sql=	String.format("select MaID,TenNhaTuyenDung,Email,TrangThai"+
				" FROM tb_NhaTuyenDung WHERE MaID = '%s'", maID);
	ResultSet rs = null;
	try {
		Statement stmt = ConnectData.connection.createStatement();
		rs = stmt.executeQuery(sql);
	} catch (SQLException e) {
		e.printStackTrace();
	}
	
	TaiKhoanNhaTuyenDung taiKhoanNhaTuyenDung = new TaiKhoanNhaTuyenDung();
	try {
		while(rs.next()){
			taiKhoanNhaTuyenDung.setMaID(maID);
			taiKhoanNhaTuyenDung.setTenNhaTuyenDung(rs.getString("tenNhaTuyenDung"));
			taiKhoanNhaTuyenDung.setEmail(rs.getString("email"));
			taiKhoanNhaTuyenDung.setTrangThai(rs.getInt("trangThai"));

		}
	} catch (SQLException e) {
		e.printStackTrace();
	}
	return taiKhoanNhaTuyenDung;
	}

	public ArrayList<TaiKhoanNhaTuyenDung> getlisttrangthaitk(int trangThai) {
		ConnectData.connection = ConnectData.getconnect();
		String sql =String.format("SELECT n.MaID,n.TenNhaTuyenDung,n.Email,t.TenTrangThai from tb_NhaTuyenDung n INNER JOIN tb_TrangThai AS t ON t.TrangThai=n.TrangThai "
				+ "where n.TrangThai='"+trangThai+"'");
		ResultSet rs = null;
		try {
			Statement stmt = ConnectData.connection.createStatement();
			rs = stmt.executeQuery(sql);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		ArrayList<TaiKhoanNhaTuyenDung>list =new ArrayList<>();
		TaiKhoanNhaTuyenDung taiKhoanNhaTuyenDung;
		try {
			while(rs.next()){
				taiKhoanNhaTuyenDung =new TaiKhoanNhaTuyenDung();
				taiKhoanNhaTuyenDung.setMaID(rs.getInt("maID"));
				taiKhoanNhaTuyenDung.setTenNhaTuyenDung(rs.getString("tenNhaTuyenDung"));
				taiKhoanNhaTuyenDung.setEmail(rs.getString("email"));
				taiKhoanNhaTuyenDung.setTentrangThai(rs.getString("tentrangThai"));
				list.add(taiKhoanNhaTuyenDung);
			}
		} catch (SQLException e) {
	
			e.printStackTrace();
		}
		return list;
	}
}

