package model.DAO;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;


import model.bean.TrangThai;

public class TrangThaidDAO {

	public ArrayList<TrangThai> getListtrangThai() {
		ConnectData.connection = ConnectData.getconnect();
		String sql= "SELECT * FROM tb_TrangThai";
		ResultSet rs=null;
		try {
			Statement stmt=ConnectData.connection.createStatement();
			rs=stmt.executeQuery(sql);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		ArrayList<TrangThai>list=new ArrayList<>();
		TrangThai trangThai;
		try {
			while(rs.next()){
				trangThai=new TrangThai();
				trangThai.setTrangThai(rs.getInt("trangThai"));
				trangThai.setTentrangThai(rs.getString("tentrangThai"));
				list.add(trangThai);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return list;
	}
	}


