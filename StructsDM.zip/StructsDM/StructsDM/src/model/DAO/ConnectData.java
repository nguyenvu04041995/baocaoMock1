package model.DAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConnectData {
static String url="jdbc:sqlserver://localhost:1433;databaseName=Mock1";
static String userName="sa";
static String password="12345678";
public static Connection connection;

public static Connection getconnect(){
	try {
		Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
    try {
				connection=DriverManager.getConnection(url,userName,password);
				System.out.println("Ket noi thanh cong");
   } catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				System.out.println("Ket noi that bai");
			}
		
	} catch (ClassNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	            System.out.println("ket noi that bai");
	}
	
	return connection;
	
}
}
