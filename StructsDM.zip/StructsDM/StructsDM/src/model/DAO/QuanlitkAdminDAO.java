package model.DAO;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import model.bean.Pagination;
import model.bean.QuanlitaikhoanAdmin;




public class QuanlitkAdminDAO {

	public ArrayList<QuanlitaikhoanAdmin> getlistquanlitkAdmin() {
		ConnectData.connection = ConnectData.getconnect();
		String sql ="SELECT TenDangNhap,MatKhau from tb_NguoiQuanTri ";
		ResultSet rs=null;
		try {
			Statement stmt=ConnectData.connection.createStatement();
			rs=stmt.executeQuery(sql);
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		ArrayList<QuanlitaikhoanAdmin>list =new ArrayList<>();
		QuanlitaikhoanAdmin quanlitaikhoanAdmin;
		try {
			while(rs.next()){
				quanlitaikhoanAdmin =new QuanlitaikhoanAdmin();
				quanlitaikhoanAdmin.setTenDangNhap(rs.getString("tenDangNhap"));
				quanlitaikhoanAdmin.setMatKhau(rs.getString("matKhau"));
				list.add(quanlitaikhoanAdmin);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		// TODO Auto-generated method stub
		return list;
	}

	public void xoatkAdmin(String tenDangNhap) {
		ConnectData.connection = ConnectData.getconnect();
		String sql=	String.format("DELETE FROM tb_NguoiQuanTri WHERE TenDangNhap = '%s'", tenDangNhap);
		System.out.println(sql);
		try {
			Statement stmt = ConnectData.connection.createStatement();
			stmt.executeUpdate(sql);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
	}

	public QuanlitaikhoanAdmin getThongTinAdmin(String tenDangNhap) {
		ConnectData.connection = ConnectData.getconnect();
		String sql=	String.format("SELECT TenDangNhap,MatKhau "+
				" FROM tb_NguoiQuanTri WHERE TenDangNhap = '%s'", tenDangNhap);
	ResultSet rs = null;
	try {
		Statement stmt = ConnectData.connection.createStatement();
		rs = stmt.executeQuery(sql);
	} catch (SQLException e) {
		e.printStackTrace();
	}
	
	QuanlitaikhoanAdmin quanlitaikhoanAdmin = new QuanlitaikhoanAdmin();
	try {
		while(rs.next()){
			quanlitaikhoanAdmin.setTenDangNhap(rs.getString("tenDangNhap"));
			quanlitaikhoanAdmin.setMatKhau(rs.getString("matKhau"));
			
		}
	} catch (SQLException e) {
		e.printStackTrace();
	}
	return quanlitaikhoanAdmin;
	}

	public void themtkAdmin(String tenDangNhap, String matKhau) {
		ConnectData.connection = ConnectData.getconnect();
		String sql=	String.format("INSERT INTO tb_NguoiQuanTri(tenDangNhap,matKhau) "+
				" VALUES ( '%s','%s' )", tenDangNhap, matKhau);
	try {
		Statement stmt = ConnectData.connection.createStatement();
		stmt.executeUpdate(sql);
	} catch (SQLException e) {
		e.printStackTrace();
	}
	}

	public void suatkAdmin(String tenDangNhap, String matKhau) {
		ConnectData.connection = ConnectData.getconnect();
		String sql=	String.format("UPDATE tb_NguoiQuanTri "+
				" SET  MatKhau = '%s' " +
				" WHERE tenDangNhap= '%s'", matKhau, tenDangNhap);
	try {
		Statement stmt = ConnectData.connection.createStatement();
		stmt.executeUpdate(sql);
	} catch (SQLException e) {
		e.printStackTrace();
	}
	}

	public ArrayList<QuanlitaikhoanAdmin> phanTrangDanhSach(int page) {
		ConnectData.connection = ConnectData.getconnect();
		int totalItem = 0;
		int itemPerPage = 5;
		int totalPage = 0;
		int offset = page * itemPerPage;
		int feetchnext = page * itemPerPage + itemPerPage;


		String sql0=	"SELECT count(TenDangNhap) as TotalItem"+
					" FROM   tb_NguoiQuanTri ";
		ResultSet rs0 = null;
		try {
			Statement stmt0 = ConnectData.connection.createStatement();
			rs0 = stmt0.executeQuery(sql0);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		try {
			while(rs0.next()){
				totalItem = rs0.getInt("TotalItem");
				totalPage = (int) Math.ceil(totalItem * 1.0 / itemPerPage);
				Pagination.page = page;
				Pagination.totalPage = totalPage;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		String sql=	""
				+ "SELECT * FROM"
				+ " ("
				+ " SELECT ROW_NUMBER() OVER ( ORDER BY TenDangNhap )  AS RowNum, TenDangNhap,MatKhau "
				+ " FROM tb_NguoiQuanTri  AS RowConstrainedResult"
				+ " WHERE   RowNum > " + offset
				+ " AND RowNum <= " + feetchnext
				+ " ORDER BY RowNum";
		ResultSet rs = null;
		try {
			Statement stmt = ConnectData.connection.createStatement();
			rs = stmt.executeQuery(sql);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		ArrayList<QuanlitaikhoanAdmin> list = new ArrayList<QuanlitaikhoanAdmin>();
		QuanlitaikhoanAdmin quanlitaikhoanAdmin;
		try {
			while(rs.next()){
				quanlitaikhoanAdmin =new QuanlitaikhoanAdmin();
				quanlitaikhoanAdmin.setTenDangNhap(rs.getString("tenDangNhap"));
				quanlitaikhoanAdmin.setMatKhau(rs.getString("matKhau"));
				list.add(quanlitaikhoanAdmin);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		page=10;
		return list;
	}

}
