package model.BO;

import java.util.ArrayList;

import model.DAO.TaiKhoanNhaTuyenDungDAO;

import model.bean.TaiKhoanNhaTuyenDung;


public class TaiKhoanNhaTuyenDungBO {
	TaiKhoanNhaTuyenDungDAO taiKhoanNhaTuyenDungDAO = new TaiKhoanNhaTuyenDungDAO();

	public ArrayList<TaiKhoanNhaTuyenDung>quanliTaiKhoanNhaTuyenDung(){
		return taiKhoanNhaTuyenDungDAO.getlistquanliTaiKhoanNhaTuyenDung();	
		
	}
	public TaiKhoanNhaTuyenDung getThongTinTaiKhoanNhaTuyenDung(int maID) {
		return taiKhoanNhaTuyenDungDAO.getThongTinTaiKhoanNhaTuyenDung(maID);
	}
	public ArrayList<TaiKhoanNhaTuyenDung> getlisttrangthaitk(int trangThai) {
		// TODO Auto-generated method stub
		return taiKhoanNhaTuyenDungDAO.getlisttrangthaitk(trangThai);
	}
}