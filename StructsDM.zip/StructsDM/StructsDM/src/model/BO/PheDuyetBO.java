package model.BO;

import java.util.ArrayList;

import model.DAO.PheDuyetDAO;
import model.bean.PheDuyet;

public class PheDuyetBO {
PheDuyetDAO pheDuyetDAO = new PheDuyetDAO();
public ArrayList<PheDuyet>getListpheDuyet(){
	return pheDuyetDAO.getListpheDuyet();
}
}
