package model.BO;

import model.DAO.AdminDAO;

public class AdminBO {
AdminDAO adminDAO =new AdminDAO();

public boolean checkLoginAdmin(String tenDangNhap,String matKhau){
	return adminDAO.checkLoginAdmin(tenDangNhap,matKhau);
	
}
}
