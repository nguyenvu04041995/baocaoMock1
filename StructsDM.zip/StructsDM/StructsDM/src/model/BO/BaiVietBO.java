package model.BO;

import java.util.ArrayList;

import model.DAO.BaiVietDAO;
import model.bean.BaiViet;





public class BaiVietBO {
BaiVietDAO baiVietDAO=new BaiVietDAO();
public ArrayList<BaiViet>quanliBaiViet(){
	return baiVietDAO.getlistquanliBaiViet();	
	
}
public void xoaBaiViet(int maBaiViet) {
	// TODO Auto-generated method stub
	baiVietDAO.xoaBaiViet(maBaiViet);
	
}
public void suaBaiViet(int maBaiViet) {
	// TODO Auto-generated method stub
	baiVietDAO.suaSinhVien(maBaiViet);
}
public BaiViet getThongTinBaiViet(int  maBaiViet) {
	return baiVietDAO.getThongTinBaiViet(maBaiViet);
}
public ArrayList<BaiViet> getlistpheDuyetBaiViet(int pheDuyet) {
	// TODO Auto-generated method stub
	return baiVietDAO.getlistpheDuyetBaiViet(pheDuyet);
}
}
