package model.BO;

import java.util.ArrayList;

import model.DAO.TrangThaidDAO;

import model.bean.TrangThai;

public class TrangThaiBO {
	TrangThaidDAO trangThaidDAO =new TrangThaidDAO();
	public ArrayList<TrangThai>getListtrangThai(){
		return trangThaidDAO.getListtrangThai();
	}
}
