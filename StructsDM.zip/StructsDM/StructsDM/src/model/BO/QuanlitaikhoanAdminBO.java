package model.BO;

import java.util.ArrayList;
import model.DAO.QuanlitkAdminDAO;
import model.bean.QuanlitaikhoanAdmin;


public class QuanlitaikhoanAdminBO {
QuanlitkAdminDAO quanlitkAdminDAO =new QuanlitkAdminDAO();

public ArrayList<QuanlitaikhoanAdmin>quanlitkAdmin(){
	return quanlitkAdminDAO.getlistquanlitkAdmin();	
}
public void xoatkAdmin(String tenDangNhap) {
	// TODO Auto-generated method stub
	quanlitkAdminDAO.xoatkAdmin(tenDangNhap);
	
}
public QuanlitaikhoanAdmin getThongTinAdmin(String tenDangNhap) {
	return quanlitkAdminDAO.getThongTinAdmin(tenDangNhap);
}
public void themtkAdmin(String tenDangNhap, String matKhau) {
	quanlitkAdminDAO.themtkAdmin(tenDangNhap, matKhau);
	
}
public void suatkAdmin(String tenDangNhap, String matKhau) {
	// TODO Auto-generated method stub
	quanlitkAdminDAO.suatkAdmin(tenDangNhap, matKhau);
}
public ArrayList<QuanlitaikhoanAdmin> getListDanhSachPhanTran(int page){
	return quanlitkAdminDAO.phanTrangDanhSach(page);
}

}
