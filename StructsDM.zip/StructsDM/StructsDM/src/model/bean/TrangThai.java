package model.bean;

public class TrangThai {
	private int trangThai;
	private String tentrangThai;
	
	/**
	 * 
	 * <code>
	 */
	
	
	
	public TrangThai() {
		super();
	}
	public TrangThai(int trangThai, String tentrangThai) {
		super();
		this.trangThai = trangThai;
		this.tentrangThai = tentrangThai;
	}
	public int getTrangThai() {
		return trangThai;
	}
	public void setTrangThai(int trangThai) {
		this.trangThai = trangThai;
	}
	public String getTentrangThai() {
		return tentrangThai;
	}
	public void setTentrangThai(String tentrangThai) {
		this.tentrangThai = tentrangThai;
	}
	

}
