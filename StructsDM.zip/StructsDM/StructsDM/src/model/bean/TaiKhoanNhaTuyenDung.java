package model.bean;

public class TaiKhoanNhaTuyenDung {
	private int maID;
	private String tenNhaTuyenDung;
	private String email;
	private int trangThai;
	private String tentrangThai;
	
	
	
	
	public String getTentrangThai() {
		return tentrangThai;
	}
	public void setTentrangThai(String tentrangThai) {
		this.tentrangThai = tentrangThai;
	}
	public int getMaID() {
		return maID;
	}
	public void setMaID(int maID) {
		this.maID = maID;
	}
	public String getTenNhaTuyenDung() {
		return tenNhaTuyenDung;
	}
	public void setTenNhaTuyenDung(String tenNhaTuyenDung) {
		this.tenNhaTuyenDung = tenNhaTuyenDung;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public int getTrangThai() {
		return trangThai;
	}
	public void setTrangThai(int trangThai) {
		this.trangThai = trangThai;
	}
	
	public TaiKhoanNhaTuyenDung(int maID, String tenNhaTuyenDung, String email, int trangThai, String tentrangThai) {
		super();
		this.maID = maID;
		this.tenNhaTuyenDung = tenNhaTuyenDung;
		this.email = email;
		this.trangThai = trangThai;
		this.tentrangThai = tentrangThai;
	}
	public TaiKhoanNhaTuyenDung() {
		super();
	}
	
	

}
