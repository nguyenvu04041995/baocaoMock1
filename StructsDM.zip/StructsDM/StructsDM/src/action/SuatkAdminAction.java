package action;



import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import form.QuanlitkAdminForm;
import model.BO.QuanlitaikhoanAdminBO;
import model.bean.QuanlitaikhoanAdmin;



public class SuatkAdminAction extends Action{
	public ActionForward execute(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		request.setCharacterEncoding("UTF-8");
		QuanlitkAdminForm quanlitkAdminForm = (QuanlitkAdminForm) form;

		QuanlitaikhoanAdminBO quanlitaikhoanAdminBO = new QuanlitaikhoanAdminBO();
	
		//sua sinh vien
		String tenDangNhap=quanlitkAdminForm.getTenDangNhap();
		if("submit".equals(quanlitkAdminForm.getSubmit())){					//nhan nut Xac nhan o trang Them sinh vien
			String matKhau= quanlitkAdminForm.getMatKhau();
			
			quanlitaikhoanAdminBO.suatkAdmin(tenDangNhap, matKhau);
			return mapping.findForward("suaAdminxong");
		} else {														//chuyen sang trang Sua sinh vien
			QuanlitaikhoanAdmin quanlitaikhoanAdmin = quanlitaikhoanAdminBO.getThongTinAdmin(tenDangNhap);
			quanlitkAdminForm.setMatKhau(quanlitaikhoanAdmin.getMatKhau());
			
			
			return mapping.findForward("suaAdmin");
		}
	}
}
