package action;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;


import form.DanhSachtkNhaTuyenDungForm;

import model.BO.TaiKhoanNhaTuyenDungBO;
import model.BO.TrangThaiBO;

import model.bean.TaiKhoanNhaTuyenDung;
import model.bean.TrangThai;

public class DanhSachtkNhaTuyenDungAction extends Action{
	@Override
	public ActionForward execute(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {

		
	
		DanhSachtkNhaTuyenDungForm danhSachtkNhaTuyenDungForm= (DanhSachtkNhaTuyenDungForm)form;
		//lay danh sach cac phe duyet
				TrangThaiBO trangThaiBO = new TrangThaiBO();
				ArrayList<TrangThai>listTrangThai = trangThaiBO.getListtrangThai();
				danhSachtkNhaTuyenDungForm.setListTrangThai(listTrangThai);
		ArrayList<TaiKhoanNhaTuyenDung> listTaiKhoanNhaTuyenDung;
		TaiKhoanNhaTuyenDungBO taiKhoanNhaTuyenDungBO = new TaiKhoanNhaTuyenDungBO();
		int  trangThai=danhSachtkNhaTuyenDungForm.getTrangThai();
		if(trangThai<0){
			listTaiKhoanNhaTuyenDung = taiKhoanNhaTuyenDungBO.quanliTaiKhoanNhaTuyenDung();
		} else {
			listTaiKhoanNhaTuyenDung = taiKhoanNhaTuyenDungBO.getlisttrangthaitk(trangThai);
		}
		
		
	/*listQuanlitaikhoanAdmin = quanlitaikhoanAdminBO.getListDanhSachPhanTran(page);*/
		
		danhSachtkNhaTuyenDungForm.setListTaiKhoanNhaTuyenDung(listTaiKhoanNhaTuyenDung);
	
		return mapping.findForward("dsNhaTuyenDung");
	}
	
}
