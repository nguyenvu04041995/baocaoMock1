package action;



import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionMessage;

import common.StringProcess;
import form.QuanlitkAdminForm;
import model.BO.QuanlitaikhoanAdminBO;


public class ThemtkAdminAction extends Action {
	@Override
	public ActionForward execute(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		request.setCharacterEncoding("UTF-8");
		QuanlitkAdminForm quanlitkAdminForm = (QuanlitkAdminForm) form;
		
		
		//validate du lieu
		if("submit".equals(quanlitkAdminForm.getSubmit())){
			ActionErrors actionErrors = new ActionErrors();
			if(StringProcess.notVaild(quanlitkAdminForm.getTenDangNhap())){
				actionErrors.add("msvError", new ActionMessage("error.tenDangNhap"));
			}
			if(StringProcess.notVaildNumber(quanlitkAdminForm.getMatKhau())){
				actionErrors.add("msvError", new ActionMessage("error.matKhau"));
			}
			saveErrors(request, actionErrors);
			if(actionErrors.size()>0){
				return mapping.findForward("themAdminerror");
			}
		}
		if("submit".equals(quanlitkAdminForm.getSubmit())){		//nhan nut Xac nhan o trang Them sinh vien
			String tenDangNhap = quanlitkAdminForm.getTenDangNhap();
			String matKhau = quanlitkAdminForm.getMatKhau();
			QuanlitaikhoanAdminBO quanlitaikhoanAdminBO = new QuanlitaikhoanAdminBO();
			quanlitaikhoanAdminBO.themtkAdmin(tenDangNhap, matKhau);
			return mapping.findForward("themAdminxong");
		} else {											//chuyen sang trang Them sinh vien
			return mapping.findForward("themAdmin");
		}
	}
}
