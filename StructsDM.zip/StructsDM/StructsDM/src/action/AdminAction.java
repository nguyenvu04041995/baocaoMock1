package action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import form.AdminForm;
import model.BO.AdminBO;



public class AdminAction extends Action {

	@Override
	public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		 AdminForm adminForm =(AdminForm)form;
		  AdminBO adminBO =new AdminBO();
		  String tenDangNhap=adminForm.getTenDangNhap();
		  String matKhau=adminForm.getMatKhau();
		  if(adminBO.checkLoginAdmin(tenDangNhap,matKhau)){
			  return mapping.findForward("thanhCong");
		  }else{
			  adminForm.setThongBao("Dang nhap khong thanh cong");
			  return mapping.findForward("thatBai");
		  }
		
	}
	

}
