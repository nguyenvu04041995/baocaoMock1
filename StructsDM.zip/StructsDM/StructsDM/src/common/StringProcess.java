package common;

public class StringProcess {

	public static boolean notVaild(String tenDangNhap) {
		if(tenDangNhap==null ||tenDangNhap.length()==0) return true;
		return false;
	}

	public static boolean notVaildNumber(String matKhau) {
		if(notVaild(matKhau)) return true;
		String r="[0-9]+";
		if(matKhau.matches(r)) return false;
		return true;
		
		
		// TODO Auto-generated method stub
	
	}
}
