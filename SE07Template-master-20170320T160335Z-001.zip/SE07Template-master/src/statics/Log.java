package statics;

public class Log {
	public static void in(Object x){
		System.out.println(x);
	}
}
