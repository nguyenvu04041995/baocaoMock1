package statics;

public class InfoSQLServer {
	public static String url = "jdbc:sqlserver://localhost:1433;databaseName=QLPT1";
	public static String userName = "sa";
	public static String password = "12345678";
}
