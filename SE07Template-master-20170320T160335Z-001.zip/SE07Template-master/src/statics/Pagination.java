package statics;

public class Pagination {
	static public int page = 1;
	static public int totalPage = 1;
	static public int itemPerPage = 5;
}
